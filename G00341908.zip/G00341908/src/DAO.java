import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

	public class DAO {

		private DataSource mysqlDS;
		
		public DAO()throws Exception{
			Context context = new InitialContext();
			String jndiName = "java:comp/env/jdbc/garage";
			mysqlDS = (DataSource) context.lookup(jndiName);
		}
		/*******************************************************************************************************************************************/
		//========================================================================================
		public ArrayList<Manufacturer> getManufacturerDetails() throws Exception{
			ArrayList<Manufacturer> manufacturers = new ArrayList<Manufacturer>();
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("select * from manufacturer");
			ResultSet myResult = myStmt.executeQuery();
			//========================================================================================	
			while(myResult.next()){
				String manu_code = myResult.getString("manu_code");
				String manu_name = myResult.getString("manu_name");
				String manu_details = myResult.getString("manu_details");
				manufacturers.add(new Manufacturer(manu_code, manu_name, manu_details));
			}
			return manufacturers;
		}
		/*******************************************************************************************************************************************/		
		/*
		 * get all Model details
		 */
		public ArrayList<Model> getModelDetails() throws Exception{
			ArrayList<Model> models = new ArrayList<Model>();
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("select * " + "from model");
			ResultSet myResult = myStmt.executeQuery();
			//========================================================================================	
			while(myResult.next()){
				
				String manu_code = myResult.getString("manu_code");
				String model_code = myResult.getString("model_code");
				String model_name = myResult.getString("model_name");
				String model_desc = myResult.getString("model_desc");
				models.add(new Model(manu_code, model_code, model_name, model_desc));
			}
			return models;
		}
		/*******************************************************************************************************************************************/
		/*
		 * get all vehicle details
		 */
		public ArrayList<Vehicle> getVehicleDetails() throws Exception{
			ArrayList<Vehicle> vehicles = new ArrayList<Vehicle>();
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("select * " + "from vehicle");
			ResultSet myResult = myStmt.executeQuery();
			//========================================================================================	
			while(myResult.next()){
				String reg = myResult.getString("reg");
				String manu_code = myResult.getString("manu_code"); 
				String model_code = myResult.getString("model_code");
				int mileage = myResult.getInt("mileage");
				double price = myResult.getDouble("price");
				String colour = myResult.getString("colour");
				String fuel = myResult.getString("fuel");
				vehicles.add(new Vehicle(reg, manu_code, model_code, mileage, price, colour, fuel));
			}
			return vehicles;
		}
		/*******************************************************************************************************************************************/
		public void addManufacturer(Manufacturer m) throws SQLException {
			// add pass through parameter to method for update insert & delete

			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("INSERT INTO manufacturer values(?, ?, ?)");

			myStmt.setString(1, m.getManu_Code());
			myStmt.setString(2, m.getManu_Name());
			myStmt.setString(3, m.getManu_Details());

			myStmt.executeUpdate();
		}
		/*******************************************************************************************************************************************/
		public void addVehicle(Vehicle v) throws SQLException {
			// TODO Auto-generated method stub
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("INSERT INTO vehicle values(?, ?, ?, ?, ?, ?, ?)");

			myStmt.setString(1, v.getReg());
			myStmt.setString(2, v.getManu_code());
			myStmt.setString(3, v.getModel_code());
			myStmt.setDouble(4, v.getMileage());
			myStmt.setDouble(5, v.getPrice());
			myStmt.setString(6, v.getColour());
			myStmt.setString(7, v.getFuel());

			myStmt.executeUpdate();
		}
		/*******************************************************************************************************************************************/
		public void addModel(Model mo) throws SQLException {
			// TODO Auto-generated method stub
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("INSERT INTO model values(?, ?, ?, ?)");

			myStmt.setString(1, mo.getManu_Code());
			myStmt.setString(2, mo.getModel_Code());
			myStmt.setString(3, mo.getModel_Name());
			myStmt.setString(4, mo.getModel_Desc());
			
			myStmt.executeUpdate();
		}
		/*******************************************************************************************************************************************/
		public void deleteManufacturer(Manufacturer m) throws SQLException {
			Connection conn = mysqlDS.getConnection();
			PreparedStatement myStmt = conn.prepareStatement("delete from manufacturer where manu_code =?");
			myStmt.setString(1, m.getManu_Code());
			myStmt.executeUpdate();
		}
		/*******************************************************************************************************************************************/
		public Manufacturer getManufacturerUpdate(Manufacturer m) throws Exception{
	        Manufacturer manufacturers = null;
	        try {
	            Connection conn = mysqlDS.getConnection(); 
	            PreparedStatement myStmt = conn.prepareStatement("select * from manufacturer where manu_code = ?");
	            myStmt.setString(1, m.getManu_Code());
	            ResultSet rs = myStmt.executeQuery();
	                
	            while (rs.next()) {
	                manufacturers = new Manufacturer(rs.getString("manu_code"), rs.getString("manu_name"), rs.getString("manu_details"));
	            }//while
	            
	            conn.close();
	            myStmt.close();
	                
	        } catch (Exception e) {
	            // TODO: handle exception
	        }       
	        return manufacturers;     
	    }
		/*******************************************************************************************************************************************/
		
		public void update(Manufacturer m) throws SQLException {
				
				Connection conn = mysqlDS.getConnection();
				PreparedStatement myStmt = conn.prepareStatement("Update manufacturer Set manu_name = ?, manu_details = ? where manu_code = ?");

				
				myStmt.setString(1, m.getManu_Name());
				myStmt.setString(2, m.getManu_Details());
				myStmt.setString(3, m.getManu_Code());

				myStmt.executeUpdate();
				conn.close();
				myStmt.close();
				
				
		}
		/*********************************************************************************************************************************************/
		/*
		 *get all details from all three tables 
		 * 
		 */
		public Vehicle getAllVehicleDetails(Vehicle v){
			 Vehicle v1 = null;
		        try {
		            Connection conn = mysqlDS.getConnection();
		            PreparedStatement myStmt = conn.prepareStatement("select v.reg, v.manu_code, man.manu_name, man.manu_details, v.model_code, mo.model_name, mo.model_desc, v.mileage, v.price, v.colour, v.fuel from vehicle v join manufacturer man on v.manu_code = man.manu_code join model mo on v.model_code = mo.model_code where reg = ?;");
		            myStmt.setString(1, v.getReg());
		            ResultSet rs = myStmt.executeQuery();
		            while (rs.next()) {
		                v1 = new Vehicle(rs.getString("manu_code"),rs.getString("manu_name"), rs.getString("manu_details"), rs.getString("model_code"),rs.getString("model_name"),rs.getString("model_desc"),rs.getString("reg"),rs.getDouble("mileage"),rs.getDouble("price"),rs.getString("colour"),rs.getString("fuel"));
				    }
		 } 
		 catch (Exception e) {
		            // TODO: handle exception
		 }       
		 return v1;     	
		}
		
	}
	
	