import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped 
public class Controller {
	
	private ArrayList<Model> models;
	private ArrayList<Manufacturer> manufacturers;
	private ArrayList<Vehicle> Vehicles;
	
	private DAO dao;

	public Controller() {
		try {
			dao = new DAO();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/************************************************************************/
	
	public void loadModels() throws Exception {
		setModels(dao.getModelDetails());
	}
	
	public ArrayList<Model> getModels() {
		return models;
	}

	public void setModels(ArrayList<Model> models) {
		this.models = models;
	}
	public String addModel(Model mo) throws Exception {
		try 
		{
			dao.addModel(mo);
			//return "hello";
			return "Model added";
		} 
		catch (Exception e) {
			return e.toString();
		}
	}
	
	/******************************************************************************************************************************
	 * 
	 * 
	 *manufacturers 
	 * 
	 */
	public void loadManufacturers() throws Exception {
		setManufacturers(dao.getManufacturerDetails());
	}
	

	public ArrayList<Manufacturer> getManufacturers() {
		return manufacturers;
	}

	public void setManufacturers(ArrayList<Manufacturer> manufacturers) {
		this.manufacturers = manufacturers;
	}
	
	public String addManufacturer(Manufacturer m) throws Exception {
		try 
		{
			dao.addManufacturer(m);
			//return "hello";
			return "Manufacturer added";
		} 
		catch (Exception e) {
			return e.toString();
		}
	}
	
	public String deleteManufacturer(Manufacturer m) throws SQLException{
		try{
			dao.deleteManufacturer(m);
			return "list manufacturer";
		}
		catch(Exception e){
			e.getMessage();
			return e.toString();
		}
		
		
	}
	
	public String update(Manufacturer m){
		try{
			dao.update(m);
			return "Manage_Manufacturers";
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
		}
		
	}
	/*
	 * this is for loading the stuff 
	 * on update details page
	 * 
	 * 
	 */
	public String updateManufacturer(Manufacturer m)throws Exception{
        try {

            Manufacturer manufacturer = dao.getManufacturerUpdate(m);
            ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();

            Map<String, Object> requestMap = externalContext.getRequestMap();
            requestMap.put("manufacturer", manufacturer);   
                
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return "UpdateManufacturer";
	}
	
	/******************************************************************************************************************************
	 * 
	 * 
	 *Vehicles 
	 * 
	 */
	 
	public void loadVehicles() throws Exception {
		setVehicles(dao.getVehicleDetails());
	}
	
	public ArrayList<Vehicle> getVehicles() {
		return Vehicles;
	}

	public void setVehicles(ArrayList<Vehicle> vehicles) {
		Vehicles = vehicles;
	}
	
	public String addVehicle(Vehicle v) throws Exception {
		try 
		{
			dao.addVehicle(v);
			//return "hello";
			return "Vehicle added";
		} 
		catch (Exception e) {
			return e.toString();
		}
	}
	/***************************************************************************************************/
	public String getAllVehicleDetails(Vehicle v) throws Exception{
		 try {

	            Vehicle vehicle = dao.getAllVehicleDetails(v);
	            ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();

	            Map<String, Object> requestMap = externalContext.getRequestMap();
	            requestMap.put("vehicle", vehicle);   
	                
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        
	        return "AllDetails";
		}
	
	/************************************************************************/
}
