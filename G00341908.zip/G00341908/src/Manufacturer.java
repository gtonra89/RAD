import javax.faces.bean.ManagedBean;
		
@ManagedBean

public class Manufacturer {

	private String manu_Code;
	private String manu_Name;
	private String manu_Details;
	
	public Manufacturer(){
		
	}
	public Manufacturer(String manu_code2, String manu_name2, String manu_details2) {
		super();
		this.manu_Code = manu_code2;
		this.manu_Name = manu_name2;
		this.manu_Details = manu_details2;
	}
	
	public String getManu_Code() {
		return manu_Code;
	}
	public void setManu_Code(String manu_Code) {
		this.manu_Code = manu_Code;
	}
	public String getManu_Name() {
		return manu_Name;
	}
	public void setManu_Name(String manu_Name) {
		this.manu_Name = manu_Name;
	}
	public String getManu_Details() {
		return manu_Details;
	}
	public void setManu_Details(String manu_Details) {
		this.manu_Details = manu_Details;
	}
	
}
